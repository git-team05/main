package team05.seller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import team05.member.MemberDAO;
import team05.member.MemberDTO;

public class SellerDAO {
	
	  private static SellerDAO instance = new SellerDAO();
	  private SellerDAO() {}
	  public static SellerDAO getInstance() {return instance;}	
	
	private Connection getConnection() throws Exception{
		Context ctx = new InitialContext();
		Context env = (Context)ctx.lookup("java:comp/env");
		DataSource ds = (DataSource)env.lookup("jdbc/orcl");
		return ds.getConnection();
	}
	
	// 판매자 회원가입
	public void insertSeller(SellerDTO dto) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		try {
			conn = getConnection();
			String sql = "insert into seller values(?,?,?,?,?,?,?,?,?,?,?,?,?,sysdate)"; //values 들어가는 순서
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPw());
			pstmt.setString(3, dto.getName());
			pstmt.setString(4, dto.getEmail());
			pstmt.setString(5, dto.getPhone());
			pstmt.setString(6, dto.getBizname());
			pstmt.setString(7, dto.getBiznum());
			pstmt.setString(8, dto.getBizaddress());
			pstmt.setString(9, dto.getCeoname());
			pstmt.setString(10, dto.getBiztel());
			pstmt.setString(11, dto.getManagername());
			pstmt.setString(12, dto.getManageremail());
			pstmt.setString(13, dto.getWebsite());
			
			pstmt.executeUpdate();
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(pstmt != null) try {pstmt.close();} catch(Exception e) {e.printStackTrace();}
			if(conn != null) try {conn.close();} catch(Exception e) {e.printStackTrace();}
		}
	}	
	// 로그인 아이디 값 일치
    public boolean idPwCheck2(String id, String pw, String kinds ) {
    	boolean result = false; 
  	  	Connection conn = null; 
        PreparedStatement pstmt = null; 
        ResultSet rs = null; 
  	  	String sql = null; 
  	  	
  	  try {
  		  conn = getConnection(); 
	  		  if(kinds.equals("member")) { 
	  			sql = "select * from member where id=? and pw=?"; 
	  		  } else if(kinds.equals("seller")) {
	  			sql = "select * from seller where id=? and pw=?";
	  		  };
  		  
  		  pstmt = conn.prepareStatement(sql); 
  		  pstmt. setString(1, id); 
  		  pstmt. setString(2, pw); 
  		 
  		  rs = pstmt.executeQuery();  
	  		  if(rs.next()) { 
	  			  result = true; 
	  		  }  		  		  
  	  }catch(Exception e) {
  		  e.printStackTrace();
  	  }finally {
  		  if(rs != null) try {rs.close();} catch(Exception e) {e.printStackTrace();}
  		  if(pstmt != null) try {pstmt.close();} catch(Exception e) {e.printStackTrace();}
          if(conn != null) try {conn.close();} catch(Exception e) {e.printStackTrace();}
  	  }
  	  return result; 
    }
}
