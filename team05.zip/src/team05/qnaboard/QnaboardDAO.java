package team05.qnaboard;

public class QnaboardDAO {

}
