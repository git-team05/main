package team05.alarm;

public class AlarmDAO {

}
