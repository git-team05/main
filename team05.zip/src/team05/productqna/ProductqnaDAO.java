package team05.productqna;

public class ProductqnaDAO {

}
