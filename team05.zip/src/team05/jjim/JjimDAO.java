package team05.jjim;

public class JjimDAO {

}
