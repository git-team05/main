package team05.product;

public class ProductDAO {

}
