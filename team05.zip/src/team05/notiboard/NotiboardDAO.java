package team05.notiboard;

public class NotiboardDAO {

}
