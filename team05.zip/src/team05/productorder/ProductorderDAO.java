package team05.productorder;

public class ProductorderDAO {

}
