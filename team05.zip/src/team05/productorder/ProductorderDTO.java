package team05.productorder;

import java.sql.Timestamp;

public class ProductorderDTO {
	private int ordernum;
	private int pronum;
	private int quantity;
	private int ordertotal;
	private String id;
	private String receiver;
	private String recphone;
	private String recemail;
	private String recaddress;
	private String delcon;
	private String paycon;
	private Timestamp reg;
	public int getOrdernum() {
		return ordernum;
	}
	public void setOrdernum(int ordernum) {
		this.ordernum = ordernum;
	}
	public int getPronum() {
		return pronum;
	}
	public void setPronum(int pronum) {
		this.pronum = pronum;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getOrdertotal() {
		return ordertotal;
	}
	public void setOrdertotal(int ordertotal) {
		this.ordertotal = ordertotal;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getRecphone() {
		return recphone;
	}
	public void setRecphone(String recphone) {
		this.recphone = recphone;
	}
	public String getRecemail() {
		return recemail;
	}
	public void setRecemail(String recemail) {
		this.recemail = recemail;
	}
	public String getRecaddress() {
		return recaddress;
	}
	public void setRecaddress(String recaddress) {
		this.recaddress = recaddress;
	}
	public String getDelcon() {
		return delcon;
	}
	public void setDelcon(String delcon) {
		this.delcon = delcon;
	}
	public String getPaycon() {
		return paycon;
	}
	public void setPaycon(String paycon) {
		this.paycon = paycon;
	}
	public Timestamp getReg() {
		return reg;
	}
	public void setReg(Timestamp reg) {
		this.reg = reg;
	}
	
	
	
}
