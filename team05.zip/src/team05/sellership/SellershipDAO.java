package team05.sellership;

public class SellershipDAO {

}
